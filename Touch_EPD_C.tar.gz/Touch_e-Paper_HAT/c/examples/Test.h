#ifndef _MAIN_H_
#define _MAIN_H_

#include <stdlib.h>     //exit()
#include <signal.h>     //signal()
#include <pthread.h>	//pthread_create()
#include "GUI_Paint.h"
#include "GUI_BMPfile.h"

int TestCode_2in13(void);
int TestCode_2in13_V3(void);
int TestCode_2in9(void);
int Flight(void);
int TestCode_SysStats(void);

#endif